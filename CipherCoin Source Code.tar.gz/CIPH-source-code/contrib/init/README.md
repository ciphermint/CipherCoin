Sample configuration files for:

SystemD: ciphercoind.service
Upstart: ciphercoind.conf
OpenRC:  ciphercoind.openrc
         ciphercoind.openrcconf
CentOS:  ciphercoind.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
